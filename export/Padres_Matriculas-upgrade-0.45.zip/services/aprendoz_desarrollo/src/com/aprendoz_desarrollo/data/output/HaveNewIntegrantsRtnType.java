
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "haveNewIntegrants" on 01/13/2014 10:25:20
 * 
 */
public class HaveNewIntegrantsRtnType {

    private Long numero;

    public HaveNewIntegrantsRtnType() {
    }

    public HaveNewIntegrantsRtnType(Long numero) {
        this.numero = numero;
    }

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

}
