
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPersonasGrupoFamiliar
 *  06/12/2013 12:22:58
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliar() {
    }

    public VistaPersonasGrupoFamiliar(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
