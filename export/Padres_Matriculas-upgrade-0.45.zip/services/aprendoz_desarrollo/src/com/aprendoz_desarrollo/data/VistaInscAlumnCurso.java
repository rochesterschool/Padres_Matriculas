
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaInscAlumnCurso
 *  06/12/2013 12:22:58
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCurso() {
    }

    public VistaInscAlumnCurso(VistaInscAlumnCursoId id) {
        this.id = id;
    }

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
