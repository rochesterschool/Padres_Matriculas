
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumAsig
 *  06/12/2013 12:22:58
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsig() {
    }

    public PadresVistaInscAlumAsig(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
