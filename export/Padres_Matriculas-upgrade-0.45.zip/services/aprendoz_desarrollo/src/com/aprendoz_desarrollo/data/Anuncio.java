
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.Anuncio
 *  06/12/2013 12:22:58
 * 
 */
public class Anuncio {

    private String anuncio;

    public Anuncio() {
    }

    public Anuncio(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
