
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hqlGetTotalPagar" on 01/13/2014 10:25:20
 * 
 */
public class HqlGetTotalPagarRtnType {

    private Double totalPagar;

    public HqlGetTotalPagarRtnType() {
    }

    public HqlGetTotalPagarRtnType(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

}
