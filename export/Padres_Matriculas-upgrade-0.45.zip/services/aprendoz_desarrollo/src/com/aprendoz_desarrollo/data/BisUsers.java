
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.BisUsers
 *  06/12/2013 12:22:59
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsers() {
    }

    public BisUsers(BisUsersId id) {
        this.id = id;
    }

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
