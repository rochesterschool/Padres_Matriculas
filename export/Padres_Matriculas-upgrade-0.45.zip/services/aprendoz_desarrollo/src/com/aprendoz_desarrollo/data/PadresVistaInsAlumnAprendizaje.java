
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInsAlumnAprendizaje
 *  04/12/2012 16:32:54
 * 
 */
public class PadresVistaInsAlumnAprendizaje {

    private PadresVistaInsAlumnAprendizajeId id;

    public PadresVistaInsAlumnAprendizaje() {
    }

    public PadresVistaInsAlumnAprendizaje(PadresVistaInsAlumnAprendizajeId id) {
        this.id = id;
    }

    public PadresVistaInsAlumnAprendizajeId getId() {
        return id;
    }

    public void setId(PadresVistaInsAlumnAprendizajeId id) {
        this.id = id;
    }

}
