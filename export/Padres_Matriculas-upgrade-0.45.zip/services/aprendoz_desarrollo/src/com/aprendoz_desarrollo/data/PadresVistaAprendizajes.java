
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaAprendizajes
 *  06/12/2013 12:22:58
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajes() {
    }

    public PadresVistaAprendizajes(PadresVistaAprendizajesId id) {
        this.id = id;
    }

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
