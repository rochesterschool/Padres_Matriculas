
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PromocionVistaInscAlumnCurso
 *  06/12/2013 12:22:58
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCurso() {
    }

    public PromocionVistaInscAlumnCurso(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
