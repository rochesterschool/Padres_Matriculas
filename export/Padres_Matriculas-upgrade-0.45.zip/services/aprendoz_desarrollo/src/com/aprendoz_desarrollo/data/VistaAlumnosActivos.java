
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaAlumnosActivos
 *  06/12/2013 12:22:58
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivos() {
    }

    public VistaAlumnosActivos(VistaAlumnosActivosId id) {
        this.id = id;
    }

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}
