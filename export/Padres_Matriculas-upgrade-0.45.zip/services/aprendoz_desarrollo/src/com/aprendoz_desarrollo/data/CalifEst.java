
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  06/12/2013 12:22:58
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEst() {
    }

    public CalifEst(CalifEstId id) {
        this.id = id;
    }

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
