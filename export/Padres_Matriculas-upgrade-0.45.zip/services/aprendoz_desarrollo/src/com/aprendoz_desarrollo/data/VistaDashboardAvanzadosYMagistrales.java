
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaDashboardAvanzadosYMagistrales
 *  06/12/2013 12:22:58
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistrales() {
    }

    public VistaDashboardAvanzadosYMagistrales(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
