
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "hq_ls_grado" on 01/13/2014 10:25:20
 * 
 */
public class Hq_ls_gradoRtnType {

    private Integer idgrado;
    private String grado;

    public Hq_ls_gradoRtnType() {
    }

    public Hq_ls_gradoRtnType(Integer idgrado, String grado) {
        this.idgrado = idgrado;
        this.grado = grado;
    }

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
