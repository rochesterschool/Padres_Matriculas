
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VProfesorAsignaturaCompleto
 *  06/12/2013 12:22:58
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompleto() {
    }

    public VProfesorAsignaturaCompleto(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
