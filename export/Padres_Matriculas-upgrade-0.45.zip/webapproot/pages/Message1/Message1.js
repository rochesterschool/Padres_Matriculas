dojo.declare("Message1", wm.Page, {
	start: function() {
		
	},
	_end: 0
});