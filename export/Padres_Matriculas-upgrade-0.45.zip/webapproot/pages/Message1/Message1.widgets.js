Message1.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		panel1: ["wm.Panel", {"height":"106px","width":"276px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
			layers1: ["wm.Layers", {}, {}, {
				layer1: ["wm.Layer", {"caption":"layer1","horizontalAlign":"left","verticalAlign":"top"}, {}, {
					picture1: ["wm.Picture", {"height":"65px","width":"100%","border":"0","source":"resources/images/loader.gif","aspect":"h"}, {}],
					label1: ["wm.Label", {"height":"33px","width":"100%","border":"0","align":"center","caption":"Enviando notificación al correo electrónico..."}, {}, {
						format: ["wm.DataFormatter", {}, {}]
					}]
				}]
			}]
		}]
	}]
}