dojo.declare("Message2", wm.Page, {
  start: function() {
    
  },
  _end: 0
});