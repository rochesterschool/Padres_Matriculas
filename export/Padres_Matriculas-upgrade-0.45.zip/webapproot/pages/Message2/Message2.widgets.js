Message2.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		panel1: ["wm.Panel", {"height":"87px","width":"251px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
			layers1: ["wm.Layers", {"height":"82px"}, {}, {
				layer1: ["wm.Layer", {"caption":"layer1","horizontalAlign":"left","verticalAlign":"top"}, {}, {
					picture1: ["wm.Picture", {"height":"35px","width":"100%","border":"0","source":"resources/images/buttons/ok.gif"}, {}],
					label1: ["wm.Label", {"height":"39px","width":"100%","border":"0","align":"center","caption":"Correo enviado satisfactoriamente. Por favor revice su bandeja  de entrada.","singleLine":false}, {}, {
						format: ["wm.DataFormatter", {}, {}]
					}]
				}]
			}]
		}]
	}]
}