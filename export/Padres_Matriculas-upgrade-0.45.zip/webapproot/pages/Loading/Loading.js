dojo.declare("Loading", wm.Page, {
  start: function() {
    
  },
  _end: 0
});